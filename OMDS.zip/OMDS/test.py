import calendar
year = 2024
month = 4

print(calendar.month(year,month))