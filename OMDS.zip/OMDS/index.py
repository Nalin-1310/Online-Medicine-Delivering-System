from flask import Flask,session,request,render_template
import mysql.connector
from mail import sendEmail

app = Flask(__name__)
app.secret_key="5878"

@app.route("/")
def index():
    return render_template("index.html")

#CUSTOMER SECTION

@app.route("/customer")
def customer():
    return render_template("customer.html")

@app.route("/customer_login_check",methods=["POST","GET"])
def customer_login_check():
    cemail = request.form["email"]
    pswd = request.form["password"]
    con, cur = database()
    qry= "SELECT * FROM customers  WHERE email='%s' AND password='%s'"
    cur.execute(qry%(cemail,pswd))
    res = cur.fetchone()
    if res:
        session["cemail"] = cemail
        return render_template("customer_home.html")
    else:
        return render_template("customer.html",msg2="invalid credentials")

@app.route("/customer_reg")
def customer_reg():
    return render_template("customer_reg.html")

@app.route("/customer_reg_store",methods=["POST","GET"])
def customer_reg_store():

    cnm = request.form["cname"]
    cemail = request.form["cemail"]
    pswd = request.form["password"]
    gen = request.form["gender"]
    mno = request.form["contact"]
    con, cur = database()
    sql = "select count(*) from customers where email='" + cemail + "' "
    cur.execute(sql)
    res = cur.fetchone()[0]
    if res > 0:
        return render_template("customer_reg.html", msg="already exists..!")
    else:
        qry = "insert into customers(name,email,password,gender,phone_number) values  ('%s','%s','%s','%s','%s')"
        cur.execute(qry % (cnm, cemail, pswd, gen, mno))
        con.commit()
        return render_template("customer.html", msg="added")

    return ""

@app.route("/chome")
def chome():
    return render_template("customer_home.html")

@app.route("/Prescription")
def Prescription():
    cemail = session["cemail"]
    con,cur = database()
    qry = "select * from medical_store "
    cur.execute(qry)
    pharmacy = cur.fetchall()
    return render_template("upaload_Prescription.html",pharmacy=pharmacy)

@app.route("/upload_prescription",methods= ["post","get"])
def upload_prescription():
    cemail = session["cemail"]
    con,cur = database()
    mnm = request.form['mname']
    prsp = request.files['file']
    qry = "insert into requests (store_name,prescription,user_email,status) values ('%s','%s','%s','%s') "
    cur.execute(qry % (mnm,prsp.filename,cemail,"wait"))
    con.commit()
    return render_template("customer_home.html",msg = "")

@app.route("/check_status")
def check_status():
    cemail = session["cemail"]
    con,cur = database()
    qry = "select * from requests where user_email='"+cemail+"'"
    cur.execute(qry)
    values = cur.fetchall()
    return render_template("check_status.html",values=values)


@app.route("/view_customer_orders")
def view_customer_orders():
    cemail = session["cemail"]
    con,cur = database()
    qry = "select * from orders where customer_email='"+cemail+"'"
    cur.execute(qry)
    values = cur.fetchall()
    return render_template("view_cust_orders.html",values=values)

@app.route("/recommendations")
def recommendations():
    con,cur = database()
    qry = "select medicine_name,description from medicine_details "
    cur.execute(qry)
    res = cur.fetchall()
    print(res)
    return render_template("recommendations.html",result=res)

#   MEDICAL STORE SECTION

@app.route("/medical_store")
def medical_store():
    return render_template("medical_store.html")

@app.route("/medicalstore_login_check",methods=["POST","GET"])
def medicalstore_login_check():
    semail = request.form["email"]
    pswd = request.form["password"]
    con, cur = database()
    qry= "SELECT * FROM medical_store  WHERE email='%s' AND password='%s'"
    cur.execute(qry%(semail,pswd))
    res = cur.fetchone()
    if res:
        session["semail"] = semail
        return render_template("medicalstore_home.html")
    else:
        return render_template("medical_store.html",msg2="invalid credentials")


@app.route("/medical_store_reg")
def medical_store_reg():
    return render_template("medical_store_reg.html")

@app.route("/medical_reg_store2",methods=["POST","GET"])
def medical_reg_store2():

    stnm = request.form["sname"]
    semail = request.form["semail"]
    pswd = request.form["password"]
    addrs = request.form["address"]
    mno = request.form["contact"]
    con, cur = database()
    sql = "select count(*) from medical_store where email='" + semail + "' "
    cur.execute(sql)
    res = cur.fetchone()[0]
    if res > 0:
        return render_template("medical_store_reg.html", msg="already exists..!")
    else:
        qry = "insert into medical_store(name,email,password,address,phone_number) values  ('%s','%s','%s','%s','%s')"
        cur.execute(qry % (stnm, semail, pswd, addrs, mno))
        con.commit()
        return render_template("medical_store.html", msg="added")

    return ""

@app.route("/shome")
def shome():
    return render_template("medicalstore_home.html")

@app.route("/company_name")
def company_name():
    return render_template("add_company_name.html")

@app.route("/adding_company_name",methods=["post","get"])
def adding_company_name():
    semail = session["semail"]
    cpnm = request.form["companyname"]
    con,cur = database()
    qry = "insert into company(companyname,store_email) values ('%s','%s')"
    cur.execute(qry % (cpnm , semail))
    con.commit()
    return render_template("medicalstore_home.html",msg="added")

@app.route("/medicine_name")
def medicine_name():
    con,cur = database()
    qry = "select * from company"
    cur.execute(qry)
    company_name = cur.fetchall()
    print("company_name",company_name)
    return render_template("add_medicine_name.html",company_name=company_name)

@app.route("/adding_medicine_name",methods=["post","get"])
def adding_medicine_name():
    semail = session["semail"]
    print("semail",semail)
    cpnm = request.form["companyname"]
    mdnm = request.form["medicinename"]
    con,cur = database()
    qry = "insert into medicine(company_name,medicine_name,store_email) values ('%s','%s','%s') "
    cur.execute(qry % (cpnm,mdnm,semail))
    con.commit()
    return render_template("medicalstore_home.html",msg2="added")

@app.route("/medicine_details")
def medicine_details():
    semail = session["semail"]
    con,cur = database()
    qry = "select * from medicine where store_email='"+semail+"'"
    cur.execute(qry)
    values = cur.fetchall()
    print("values",values)
    print("values", values[0][1])
    print("values", values[0][2])
    '''for values in values:
        company_name = values[1]
        medicine_name = values[2]'''
    return render_template("add_medicine_details.html",values=values,company_name=company_name,medicine_name=medicine_name)

@app.route("/add_medicine_details",methods=["post","get"])
def add_medicine_details():
    semail = session["semail"]

    cpnm = request.form["companyname"]
    mdnm = request.form["medicinename"]
    desc = request.form["description"]
    expdate = request.form["expdate"]
    cost = request.form["cost"]
    stcnt = request.form["stockcount"]
    image = request.files["file"]
    con, cur = database()

    qry = "insert into medicine_details(company_name,medicine_name,description,expiry_date,cost,stock_count,image,store_email) values (%s,%s,%s,%s,%s,%s,%s,%s) "
    values = (cpnm,mdnm,desc,expdate,cost,stcnt,image.filename,semail)
    cur.execute(qry,values)#cpnm, mdnm, desc, expdate, cost, stcnt, image, semail))
    con.commit()
    return render_template("medicalstore_home.html",msg3="added")

@app.route("/view_orders")
def view_orders():
    con, cur = database()
    semail = session["semail"]
    sql = "select name from medical_store where email='" + semail + "'"
    cur.execute(sql)
    name = cur.fetchone()
    name = name[0]
    print(name)
    qry = "select * from requests where store_name='"+name+"' and status='wait'"
    cur.execute(qry)
    res = cur.fetchall()
    return render_template("view_orders.html",values=res)

@app.route("/view_photo/<sno>")
def view_photo(sno):
    con,cur = database()
    qry = "select prescription from requests where sno='"+sno+"'"
    cur.execute(qry)
    image=cur.fetchone()[0]
    return render_template("view_prescription.html",image=image)

@app.route("/view_medicines")
def view_medicines():
    con, cur = database()
    semail = session["semail"]
    qry = "select * from medicine_details where store_email='"+semail+"' "
    cur.execute(qry)
    res = cur.fetchall()
    return render_template("test.html",values=res)

@app.route("/store_accept/<sno>")
def store_accept(sno):
    con, cur = database()
    sql = "update requests set status='Accepted'  where sno='" + sno + "'"
    cur.execute(sql)
    con.commit()

    semail = session["semail"]
    sql = "select name from medical_store where email='" + semail + "'"
    cur.execute(sql)
    name = cur.fetchone()
    name = name[0]
    print(name)
    qry = "select * from requests where store_name='" + name + "' and status='wait'"
    cur.execute(qry)
    res = cur.fetchall()
    return render_template("view_orders.html", values=res,msg="order accepted")

@app.route("/store_reject/<sno>")
def store_reject(sno):
    con, cur = database()
    sql = "update requests set status='Rejected'  where sno='" + sno + "'"
    cur.execute(sql)
    con.commit()

    semail = session["semail"]
    sql = "select name from medical_store where email='" + semail + "'"
    cur.execute(sql)
    name = cur.fetchone()
    name = name[0]

    qry = "select * from requests where store_name='"+name+"' and  status='wait'"
    cur.execute(qry)
    rslt = cur.fetchall()
    return render_template("view_orders.html", values=rslt, msg2="ordder rejected")


@app.route("/addtocart/<sno>")
def addtocart(sno):
    con, cur = database()
    semail = session["semail"]
    qry = "select * from medicine_details where sno='" + sno + "' "
    cur.execute(qry)
    res = cur.fetchall()
    return render_template("test2.html",values=res)

@app.route("/add_to_cart",methods=["post","get"])
def add_to_cart():

    pid = request.form['pid']
    name = request.form['name']
    cost = request.form['cost']
    image = request.form['image']
    semail = request.form['semail']
    qty = request.form['qty']
    stock_count = request.form['stock_count']

    total = int(cost)*int(qty)
    print("total",total)

    con,cur = database()
    qry = "insert into cart(product_id,name,cost,image,quantity,total,semail) values(%s,%s,%s,%s,%s,%s,%s)"
    values = (pid,name,cost,image,qty,total,semail)
    cur.execute(qry, values )
    con.commit()
    stock_count = int(stock_count)-int(qty)
    #stock_count = str(stock_count)
    print("stock",stock_count)
    qry2 = "update medicine_details set stock_count='"+str(stock_count)+"' where sno='"+pid+"'"
    cur.execute(qry2)
    con.commit()
    semail = session["semail"]
    qry3 = "select * from medicine_details where store_email='" + semail + "' "
    cur.execute(qry3)
    res = cur.fetchall()
    return render_template("test.html", values=res,msg="added")

@app.route("/view_cart")
def view_cart():
    semail = session["semail"]
    con,cur = database()
    qry3 = "select name from medical_store where email='"+semail+"'"
    cur.execute(qry3)
    name = cur.fetchone()[0]
    qry = "select * from cart where semail='"+semail+"'"
    cur.execute(qry)
    res1 = cur.fetchall()
    print("car", res1)
    totalcost = 0
    for res in res1:
        totalcost = int(res[6])+ totalcost

    qry2 = "select user_email from requests where store_name='"+name+"' "
    cur.execute(qry2)
    mails = cur.fetchall()
    print("mails",mails)

    return render_template("cart.html",values=res1,totalcost=str(totalcost),mails=mails)

@app.route("/send_email",methods=["post","get"])
def send_email():
    semail = session["semail"]
    bill = request.form['bill']
    mail = request.form['mailid']
    date = request.form['date']
    body_text="Toal Price: Rs."+bill+" \n"+"your medicine will  delivered on:"+date
    msg = sendEmail(mail,"Medicine Bill",body_text)
    con,cur = database()
    qry = "select * from cart where semail='"+semail+"'"
    cur.execute(qry)
    vals = cur.fetchall()
    for val in vals:
        qry2 = "insert into orders(product_id,medicine_name,cost,quantity,total,image,customer_email,store_email) values('%s','%s','%s','%s','%s','%s','%s','%s')"
        cur.execute(qry2 %(val[1], val[2], val[3], val[5],val[6],val[4],mail,val[7]))
        con.commit()
    dq = " DELETE  from cart where semail='" + semail + "' "
    cur.execute(dq)
    con.commit()
    qry3 = "select * from cart where semail='"+semail+"'"
    cur.execute(qry3)
    res = cur.fetchall()
    return render_template("cart.html",values=res,msg2="medicine bill details sent successfully")



#DATABASE CONNECTION

def database():
    con = mysql.connector.connect(host="127.0.0.1", user="root", password="root", database="online_medicine")
    cur = con.cursor()
    return con,cur

if __name__=='__main__':
    app.run(port="2024",host="localhost",debug=True)

