import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.message import EmailMessage
'''def sendEmail(receiver_email,subject,message):
	# Email configuration
	sender_email = "myprojectmail@ctcorphyd.com"
	password = "myprojectmail#304"
	receiver_email = receiver_email

	# Create a message
	message = MIMEMultipart()
	message["From"] = sender_email
	message["To"] = receiver_email
	message["Subject"] = subject

	# Add body to email
	body = message
	message.attach(MIMEText(body, "plain"))

	# Connect to SMTP server
	with smtplib.SMTP_SSL("mail.ctcorphyd.com", 465) as server:
	    server.login(sender_email, password)
	    server.sendmail(sender_email, receiver_email, message.as_string().encode('UTF-8'))

	print("Email sent successfully!")'''


def sendEmail(receiver_email,subject,body_text):
	# Email configuration
	sender_email = "myprojectmail@ctcorphyd.com"
	password = "myprojectmail#304"
	receiver_email = receiver_email

	# Create a message
	message =  EmailMessage()
	message["From"] = sender_email
	message["To"] = receiver_email
	message["Subject"] = subject
	#message["date"] = date

	message.set_content(body_text) 

	# Add body to email

	# Connect to SMTP server
	with smtplib.SMTP_SSL("mail.ctcorphyd.com", 465) as server:
	    server.login(sender_email, password)
	    #server.sendmail(sender_email, receiver_email, message.as_string().encode('UTF-8'))
	    server.send_message(message)

	msg = print("Email sent successfully!")
	return msg

#sendEmail("jagapatim1999@gmail.com","testing","hi")