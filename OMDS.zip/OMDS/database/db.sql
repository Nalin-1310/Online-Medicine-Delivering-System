/*
SQLyog Community Edition- MySQL GUI v6.07
Host - 5.5.30 : Database - online_medicine
*********************************************************************
Server version : 5.5.30
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

create database if not exists `online_medicine`;

USE `online_medicine`;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

/*Table structure for table `cart` */

DROP TABLE IF EXISTS `cart`;

CREATE TABLE `cart` (
  `sno` int(30) NOT NULL AUTO_INCREMENT,
  `product_id` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `cost` varchar(100) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  `quantity` varchar(100) DEFAULT NULL,
  `total` varchar(100) DEFAULT NULL,
  `semail` varchar(100) DEFAULT NULL,
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

/*Data for the table `cart` */

/*Table structure for table `company` */

DROP TABLE IF EXISTS `company`;

CREATE TABLE `company` (
  `sno` int(50) NOT NULL AUTO_INCREMENT,
  `companyname` varchar(100) DEFAULT NULL,
  `store_email` varchar(100) DEFAULT NULL,
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `company` */

insert  into `company`(`sno`,`companyname`,`store_email`) values (1,'Divis','apollo@gmail.com'),(4,'reddys','apollo@gmail.com'),(5,'ramkee','medicover@gmail.com');

/*Table structure for table `customers` */

DROP TABLE IF EXISTS `customers`;

CREATE TABLE `customers` (
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `phone_number` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `customers` */

insert  into `customers`(`name`,`email`,`password`,`gender`,`phone_number`) values ('mani','jagapatim1999@gmail.com','587858','male','8978437835'),('ct','ct@gmail.com','1234','Male','1234567890');

/*Table structure for table `medical_store` */

DROP TABLE IF EXISTS `medical_store`;

CREATE TABLE `medical_store` (
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `phone_number` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `medical_store` */

insert  into `medical_store`(`name`,`email`,`password`,`address`,`phone_number`) values ('Apollo','apollo@gmail.com','12345','siri towers304,prime hospital line,ameerpet,hyderabad','7799427827'),('medicover','medicover@gmail.com','12345','sai towers,jubleehills,hyderbad','8978437835');

/*Table structure for table `medicine` */

DROP TABLE IF EXISTS `medicine`;

CREATE TABLE `medicine` (
  `sno` int(10) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(100) DEFAULT NULL,
  `medicine_name` varchar(100) DEFAULT NULL,
  `store_email` varchar(100) DEFAULT NULL,
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `medicine` */

insert  into `medicine`(`sno`,`company_name`,`medicine_name`,`store_email`) values (2,'Divis','paracetamol','apollo@gmail.com'),(4,'reddys','Dolo 650','apollo@gmail.com'),(5,'ramkee','citrizen','medicover@gmail.com');

/*Table structure for table `medicine_details` */

DROP TABLE IF EXISTS `medicine_details`;

CREATE TABLE `medicine_details` (
  `sno` int(30) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(100) DEFAULT NULL,
  `medicine_name` varchar(100) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `expiry_date` varchar(100) DEFAULT NULL,
  `cost` varchar(100) DEFAULT NULL,
  `stock_count` varchar(100) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  `store_email` varchar(100) DEFAULT NULL,
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `medicine_details` */

insert  into `medicine_details`(`sno`,`company_name`,`medicine_name`,`description`,`expiry_date`,`cost`,`stock_count`,`image`,`store_email`) values (2,'Divis','paracetamol','Paracetamol is a medicine used to treat mild to moderate pain','2024-03-18','45','3','paracetamol1.jpg','apollo@gmail.com'),(3,'reddys','Dolo 650','headaches, mild to high fevers, and any other type of bodily aches','2027-06-16','105','42','dolo.jpeg','apollo@gmail.com'),(4,'ramkee','citrizen','emporarily relieve the symptoms of hay fever (allergy to pollen, dust, or other substances in the air) and allergy to other substances','2024-03-15','25','15','citrizen.jpeg','medicover@gmail.com');

/*Table structure for table `orders` */

DROP TABLE IF EXISTS `orders`;

CREATE TABLE `orders` (
  `product_id` varchar(10) DEFAULT NULL,
  `medicine_name` varchar(100) DEFAULT NULL,
  `cost` varchar(100) DEFAULT NULL,
  `quantity` varchar(100) DEFAULT NULL,
  `total` varchar(100) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `store_email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `orders` */

insert  into `orders`(`product_id`,`medicine_name`,`cost`,`quantity`,`total`,`image`,`customer_email`,`store_email`) values ('2','paracetamol','45','3','135','paracetamol1.jpg','jagapatim1999@gmail.com','apollo@gmail.com'),('3','Dolo 650','105','5','525','dolo.jpeg','jagapatim1999@gmail.com','apollo@gmail.com'),('4','citrizen','25','5','125','citrizen.jpeg','ct@gmail.com','medicover@gmail.com');

/*Table structure for table `requests` */

DROP TABLE IF EXISTS `requests`;

CREATE TABLE `requests` (
  `sno` int(30) NOT NULL AUTO_INCREMENT,
  `store_name` varchar(100) DEFAULT NULL,
  `prescription` varchar(100) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `requests` */

insert  into `requests`(`sno`,`store_name`,`prescription`,`user_email`) values (1,'Apollo','prescription.jpeg','jagapatim1999@gmail.com'),(3,'medicover','prescription.jpeg','ct@gmail.com');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
